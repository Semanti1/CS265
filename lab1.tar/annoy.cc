#include <iostream>

using std::cout;
using std::endl;

int main()
{
	for( long i=0; i<100; --i )
		cout << "Infinite Loop?" << endl;

	return 0;
}
